﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace StepicGamesWF
{
    public static class LocalJogoStorage
    {
        private static string arquivoJogos = "jogos.xml"; // Nome do arquivo para salvar os jogos

        public static void SalvarJogos(List<Jogo> listaDeJogos)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Jogo>));
            using (TextWriter tw = new StreamWriter(arquivoJogos))
            {
                xmlSerializer.Serialize(tw, listaDeJogos);
            }
        }

        public static List<Jogo> CarregarJogos()
        {
            List<Jogo> listaDeJogos = new List<Jogo>();
            if (File.Exists(arquivoJogos))
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Jogo>));
                using (TextReader tr = new StreamReader(arquivoJogos))
                {
                    listaDeJogos = (List<Jogo>)xmlSerializer.Deserialize(tr);
                }
            }
            return listaDeJogos;
        }
    }
}
