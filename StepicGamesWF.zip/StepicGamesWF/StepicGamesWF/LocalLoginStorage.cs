﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StepicGamesWF
{
    public class LocalLoginStorage
    {
        private const string arquivoUsuarios = "usuarios.txt";

        public static bool CadastrarUsuario(string usuario, string senha)
        {
            try
            {
                using (StreamWriter writer = File.AppendText(arquivoUsuarios))
                {
                    writer.WriteLine($"{usuario},{senha}");
                }
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao cadastrar usuário: {ex.Message}");
                return false;
            }
        }

        public static bool VerificarLogin(string usuario, string senha)
        {
            try
            {
                if (File.Exists(arquivoUsuarios))
                {
                    string[] linhas = File.ReadAllLines(arquivoUsuarios);

                    foreach (string linha in linhas)
                    {
                        string[] dados = linha.Split(',');

                        if (dados[0] == usuario && dados[1] == senha)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao verificar login: {ex.Message}");
                return false;
            }
        }
    }
}
