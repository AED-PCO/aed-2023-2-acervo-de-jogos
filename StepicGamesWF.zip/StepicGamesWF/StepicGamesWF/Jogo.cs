﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StepicGamesWF
{
    public class Jogo
    {
        public string Nome { get; set; }
        public double Valor { get; set; }
        public bool Alugado { get; set; }
        public string RGCliente { get; set; } // Novo campo para armazenar o RG do cliente
    }
}
