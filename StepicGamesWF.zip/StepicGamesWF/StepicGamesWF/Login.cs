﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StepicGamesWF
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void TxtUsuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnCad_Click(object sender, EventArgs e)
        {
            string username = TxtUsuario.Text;
            string password = TxtSenha.Text;

            // Verifica se os campos não estão vazios
            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
            {
                // Utilizando a classe LocalLoginStorage para cadastrar o usuário
                if (LocalLoginStorage.CadastrarUsuario(username, password))
                {
                    MessageBox.Show("Cadastro realizado com sucesso!");
                    // Limpa os campos após o cadastro
                    TxtUsuario.Text = "";
                    TxtSenha.Text = "";
                }
                else
                {
                    MessageBox.Show("Erro ao cadastrar usuário.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, preencha todos os campos.");
            }
        }

        private void BtnAcesso_Click(object sender, EventArgs e)
        {
            string username = TxtUsuario.Text;
            string password = TxtSenha.Text;

            if (LocalLoginStorage.VerificarLogin(username, password))
            {
                MessageBox.Show("Login bem-sucedido!");

                // Oculta o formulário atual (de login)
                this.Hide();

                // Cria uma instância do formulário principal
                NovoJogo formPrincipal = new NovoJogo();

                // Exibe o formulário principal
                formPrincipal.Show();
            }
            else
            {
                MessageBox.Show("Credenciais inválidas. Tente novamente.");
                TxtSenha.Text = "";
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void lbluser_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblpass_Click(object sender, EventArgs e)
        {

        }

        private void TxtSenha_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
