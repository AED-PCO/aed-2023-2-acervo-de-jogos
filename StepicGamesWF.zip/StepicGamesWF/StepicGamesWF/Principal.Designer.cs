﻿namespace StepicGamesWF
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddJogoN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AddJogoN
            // 
            this.AddJogoN.Location = new System.Drawing.Point(132, 88);
            this.AddJogoN.Name = "AddJogoN";
            this.AddJogoN.Size = new System.Drawing.Size(253, 47);
            this.AddJogoN.TabIndex = 0;
            this.AddJogoN.Text = "Adicionar Novo Jogo";
            this.AddJogoN.UseVisualStyleBackColor = true;
            this.AddJogoN.Click += new System.EventHandler(this.button1_Click);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 552);
            this.Controls.Add(this.AddJogoN);
            this.Name = "Principal";
            this.Text = "Principal";
            this.Load += new System.EventHandler(this.Principal_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button AddJogoN;
    }
}