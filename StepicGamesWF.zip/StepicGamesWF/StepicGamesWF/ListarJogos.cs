﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StepicGamesWF
{
    public partial class ListarJogos : Form
    {
        private Dictionary<string, Jogo> dicionarioDeJogos; // Dicionário para armazenar os jogos

        // Construtor que recebe a lista de jogos como parâmetro
        public ListarJogos(List<Jogo> jogos)
        {
            InitializeComponent();

            // Cria um dicionário onde a chave é o nome do jogo e o valor é o objeto Jogo
            dicionarioDeJogos = new Dictionary<string, Jogo>();
            foreach (var jogo in jogos)
            {
                dicionarioDeJogos[jogo.Nome] = jogo;
            }

            // Exibe os jogos na ListBox quando a tela for carregada
            this.Load += new EventHandler(ListarJogos_Load);
        }

        private void ListarJogos_Load(object sender, EventArgs e)
        {
            ExibirJogosOrdenadosPorPreco();
        }

        private void ExibirJogosOrdenadosPorPreco()
        {
            // Ordena os jogos por preço (valor)
            List<Jogo> jogosOrdenadosPorPreco = new List<Jogo>(dicionarioDeJogos.Values);
            jogosOrdenadosPorPreco.Sort((j1, j2) => j1.Valor.CompareTo(j2.Valor));

            // Limpa a listBox1 antes de exibir os jogos ordenados por preço
            listBox1.Items.Clear();

            // Adiciona os jogos ordenados por preço à listBox1 para exibição
            foreach (var jogo in jogosOrdenadosPorPreco)
            {
                string statusAlugado = jogo.Alugado ? $"ALUGADO para {jogo.RGCliente}" : "NÃO ALUGADO";
                listBox1.Items.Add($"Nome: {jogo.Nome}, Valor: {jogo.Valor}, Status: {statusAlugado}");
            }
        }


        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Lógica para lidar com a seleção na ListBox, se necessário
        }
    }
}
