﻿namespace StepicGamesWF
{
    partial class NovoJogo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtValor = new System.Windows.Forms.TextBox();
            this.TxtJogo = new System.Windows.Forms.TextBox();
            this.lblpass = new System.Windows.Forms.Label();
            this.lbluser = new System.Windows.Forms.Label();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.BtnRem = new System.Windows.Forms.Button();
            this.BtnAlugar = new System.Windows.Forms.Button();
            this.BtnDevolver = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtCliente = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // TxtValor
            // 
            this.TxtValor.Location = new System.Drawing.Point(125, 157);
            this.TxtValor.Margin = new System.Windows.Forms.Padding(2);
            this.TxtValor.Name = "TxtValor";
            this.TxtValor.Size = new System.Drawing.Size(322, 20);
            this.TxtValor.TabIndex = 10;
            // 
            // TxtJogo
            // 
            this.TxtJogo.Location = new System.Drawing.Point(125, 113);
            this.TxtJogo.Margin = new System.Windows.Forms.Padding(2);
            this.TxtJogo.Name = "TxtJogo";
            this.TxtJogo.Size = new System.Drawing.Size(322, 20);
            this.TxtJogo.TabIndex = 9;
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.6F);
            this.lblpass.Location = new System.Drawing.Point(64, 157);
            this.lblpass.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(57, 22);
            this.lblpass.TabIndex = 8;
            this.lblpass.Text = "Valor:";
            // 
            // lbluser
            // 
            this.lbluser.AutoSize = true;
            this.lbluser.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.6F);
            this.lbluser.Location = new System.Drawing.Point(67, 113);
            this.lbluser.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(54, 22);
            this.lbluser.TabIndex = 7;
            this.lbluser.Text = "Jogo:";
            // 
            // BtnAdd
            // 
            this.BtnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.6F);
            this.BtnAdd.Location = new System.Drawing.Point(68, 256);
            this.BtnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(180, 48);
            this.BtnAdd.TabIndex = 6;
            this.BtnAdd.Text = "Adicionar";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.6F);
            this.button1.Location = new System.Drawing.Point(66, 325);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 47);
            this.button1.TabIndex = 11;
            this.button1.Text = "Listar Jogos";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BtnRem
            // 
            this.BtnRem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.6F);
            this.BtnRem.Location = new System.Drawing.Point(66, 385);
            this.BtnRem.Margin = new System.Windows.Forms.Padding(2);
            this.BtnRem.Name = "BtnRem";
            this.BtnRem.Size = new System.Drawing.Size(182, 47);
            this.BtnRem.TabIndex = 12;
            this.BtnRem.Text = "Remover";
            this.BtnRem.UseVisualStyleBackColor = true;
            this.BtnRem.Click += new System.EventHandler(this.BtnRem_Click);
            // 
            // BtnAlugar
            // 
            this.BtnAlugar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.6F);
            this.BtnAlugar.Location = new System.Drawing.Point(288, 257);
            this.BtnAlugar.Margin = new System.Windows.Forms.Padding(2);
            this.BtnAlugar.Name = "BtnAlugar";
            this.BtnAlugar.Size = new System.Drawing.Size(182, 47);
            this.BtnAlugar.TabIndex = 13;
            this.BtnAlugar.Text = "Alugar";
            this.BtnAlugar.UseVisualStyleBackColor = true;
            this.BtnAlugar.Click += new System.EventHandler(this.BtnAlugar_Click);
            // 
            // BtnDevolver
            // 
            this.BtnDevolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.6F);
            this.BtnDevolver.Location = new System.Drawing.Point(288, 325);
            this.BtnDevolver.Margin = new System.Windows.Forms.Padding(2);
            this.BtnDevolver.Name = "BtnDevolver";
            this.BtnDevolver.Size = new System.Drawing.Size(182, 47);
            this.BtnDevolver.TabIndex = 14;
            this.BtnDevolver.Text = "Devolver";
            this.BtnDevolver.UseVisualStyleBackColor = true;
            this.BtnDevolver.Click += new System.EventHandler(this.BtnDevolver_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.6F);
            this.BtnSair.Location = new System.Drawing.Point(288, 385);
            this.BtnSair.Margin = new System.Windows.Forms.Padding(2);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(182, 47);
            this.BtnSair.TabIndex = 15;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(221, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 34);
            this.label1.TabIndex = 16;
            this.label1.Text = "MENU";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.6F);
            this.label2.Location = new System.Drawing.Point(67, 190);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 22);
            this.label2.TabIndex = 17;
            this.label2.Text = "Cliente:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // TxtCliente
            // 
            this.TxtCliente.Location = new System.Drawing.Point(138, 192);
            this.TxtCliente.Margin = new System.Windows.Forms.Padding(2);
            this.TxtCliente.Name = "TxtCliente";
            this.TxtCliente.Size = new System.Drawing.Size(309, 20);
            this.TxtCliente.TabIndex = 18;
            // 
            // NovoJogo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 496);
            this.Controls.Add(this.TxtCliente);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnDevolver);
            this.Controls.Add(this.BtnAlugar);
            this.Controls.Add(this.BtnRem);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.TxtValor);
            this.Controls.Add(this.TxtJogo);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.lbluser);
            this.Controls.Add(this.BtnAdd);
            this.Name = "NovoJogo";
            this.Text = "NovoJogo";
            this.Load += new System.EventHandler(this.NovoJogo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtValor;
        private System.Windows.Forms.TextBox TxtJogo;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.Label lbluser;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button BtnRem;
        private System.Windows.Forms.Button BtnAlugar;
        private System.Windows.Forms.Button BtnDevolver;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtCliente;
    }
}