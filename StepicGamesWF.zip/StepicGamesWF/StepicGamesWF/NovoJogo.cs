﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StepicGamesWF
{
    public partial class NovoJogo : Form
    {
        private List<Jogo> listaDeJogos;

        public NovoJogo()
        {
            InitializeComponent();
            listaDeJogos = LocalJogoStorage.CarregarJogos();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string nomeJogo = TxtJogo.Text;
            double valor;

            if (double.TryParse(TxtValor.Text, out valor))
            {
                if (JogoExiste(nomeJogo))
                {
                    MessageBox.Show("Este jogo já está na lista.");
                }
                else
                {
                    Jogo novoJogo = new Jogo { Nome = nomeJogo, Valor = valor, Alugado = false };
                    listaDeJogos.Add(novoJogo);
                    MessageBox.Show("Jogo adicionado à lista.");
                    AtualizarListarJogos();
                    SalvarJogosLocalmente();
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira um valor válido.");
            }
        }

        private void AtualizarListarJogos()
        {
            ListarJogos telaListarJogos = new ListarJogos(listaDeJogos);
            telaListarJogos.Show();
        }

        private bool JogoExiste(string nomeJogo)
        {
            foreach (var jogo in listaDeJogos)
            {
                if (jogo.Nome.Equals(nomeJogo, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        private void SalvarJogosLocalmente()
        {
            LocalJogoStorage.SalvarJogos(listaDeJogos);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ListarJogos telaListarJogos = new ListarJogos(listaDeJogos);
            telaListarJogos.Show();
        }

        private void BtnRem_Click(object sender, EventArgs e)
        {
            string nomeJogoRemover = TxtJogo.Text;

            if (!string.IsNullOrEmpty(nomeJogoRemover))
            {
                Jogo jogoARemover = listaDeJogos.FirstOrDefault(j => j.Nome.Equals(nomeJogoRemover, StringComparison.OrdinalIgnoreCase));

                if (jogoARemover != null)
                {
                    listaDeJogos.Remove(jogoARemover);
                    AtualizarListarJogos();
                    SalvarJogosLocalmente();
                }
                else
                {
                    MessageBox.Show("Jogo não encontrado na lista.");
                }
            }
            else
            {
                MessageBox.Show("Insira um nome de jogo para remover.");
            }
        }

        private void NovoJogo_Load(object sender, EventArgs e)
        {

        }

        private void BtnAlugar_Click(object sender, EventArgs e)
        {
            string nomeJogoAlugar = TxtJogo.Text;
            string rgCliente = TxtCliente.Text; // Obtém o RG do cliente

            if (!string.IsNullOrEmpty(nomeJogoAlugar))
            {
                Jogo jogoAlugar = listaDeJogos.FirstOrDefault(j => j.Nome.Equals(nomeJogoAlugar, StringComparison.OrdinalIgnoreCase));

                if (jogoAlugar != null)
                {
                    if (!jogoAlugar.Alugado)
                    {
                        if (!string.IsNullOrEmpty(rgCliente)) // Verifica se o RG do cliente foi inserido
                        {
                            // Simulando o aluguel por um tempo (por exemplo, 7 dias)
                            jogoAlugar.Alugado = true;
                            jogoAlugar.RGCliente = rgCliente; // Armazena o RG do cliente
                            MessageBox.Show($"O jogo {nomeJogoAlugar} foi alugado com sucesso por 7 dias para {rgCliente}.");
                            AtualizarListarJogos();
                            SalvarJogosLocalmente();
                        }
                        else
                        {
                            MessageBox.Show("Insira o Nome Completo do cliente para alugar o jogo.");
                        }
                    }
                    else
                    {
                        MessageBox.Show($"O jogo {nomeJogoAlugar} já está alugado.");
                    }
                }
                else
                {
                    MessageBox.Show("Jogo não encontrado na lista.");
                }
            }
            else
            {
                MessageBox.Show("Insira um nome de jogo para alugar.");
            }
        }


        private void BtnDevolver_Click(object sender, EventArgs e)
        {
            string nomeJogoDevolver = TxtJogo.Text;

            if (!string.IsNullOrEmpty(nomeJogoDevolver))
            {
                Jogo jogoDevolver = listaDeJogos.FirstOrDefault(j => j.Nome.Equals(nomeJogoDevolver, StringComparison.OrdinalIgnoreCase));

                if (jogoDevolver != null)
                {
                    if (jogoDevolver.Alugado)
                    {
                        jogoDevolver.Alugado = false; // Define o status como não alugado
                        jogoDevolver.RGCliente = null; // Remove o RG do cliente ao devolver o jogo
                        MessageBox.Show($"O jogo {nomeJogoDevolver} foi devolvido com sucesso.");
                        AtualizarListarJogos();
                        SalvarJogosLocalmente();
                    }
                    else
                    {
                        MessageBox.Show($"O jogo {nomeJogoDevolver} não está alugado.");
                    }
                }
                else
                {
                    MessageBox.Show("Jogo não encontrado na lista.");
                }
            }
            else
            {
                MessageBox.Show("Insira um nome de jogo para devolver.");
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            // Limpar o estado do login (por exemplo, desfazer o login)
            // Você pode adicionar lógica aqui para deslogar o usuário, se necessário

            // Fechar o formulário atual (NovoJogo)
            this.Close();

            // Mostrar a tela de login novamente
            Login telaDeLogin = new Login();
            telaDeLogin.Show();
        }

        private void BtnPreco_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}